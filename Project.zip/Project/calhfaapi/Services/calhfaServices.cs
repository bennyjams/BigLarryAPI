using System.Threading.Tasks;
using System.Net.Http;
using System.Text.Json;
using calhfaapi.Models;

namespace calhfaapi.Services
{

 public class Covid19Service
 {

  private readonly HttpClient client = new HttpClient();

  public async Task<Stats> GetWorldStats()
  {
   var worldStatTask = client.GetStreamAsync("https://api.covid19api.com/world/total");

   var worldStat = await JsonSerializer.DeserializeAsync<Stats>(await worldStatTask);

   return worldStat;


  }
 }

}