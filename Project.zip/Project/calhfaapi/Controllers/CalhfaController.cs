using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using calhfaapi.Services;
using calhfaapi.Models;

namespace calhfaapi.Controller
{
 [Route("api/[controller]/[action]")]
 [ApiController]
 public class CalhfaController : ControllerBase
 {

  private readonly Covid19Service _myobject;

  public CalhfaController(Covid19Service obj)
  {

   //allot this obj to out internal object of service class
   _myobject = obj;

  }

  [HttpGet]

  public async Task<ActionResult<Stats>> sequence()
  {
   return await _myobject.GetWorldStats();
  }

 }
}