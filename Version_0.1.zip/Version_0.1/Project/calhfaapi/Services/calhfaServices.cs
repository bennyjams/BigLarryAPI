using System.Threading.Tasks;
using System.Net.Http;
using System.Text.Json;
using calhfaapi.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;

namespace calhfaapi.Services
{
 public class CalHFAService
 {
         private IConfiguration Configuration;
         public CalHFAService(IConfiguration con) {
           Configuration = con;
         }

    public String Get() {
 
 //Getting connection String
    SqlConnection cnn = new SqlConnection(Configuration.GetConnectionString("DefaultConnectionString"));
    // SqlConnection cnn = new SqlConnection("Data Source=.;Initial Catalog=BigLarry;Integrated Security=True;");

    cnn.Open();
            
    SqlCommand com = new SqlCommand("SELECT COUNT(*) FROM LoanStatus WHERE StatusCode >= 410", cnn);
    var count = (int)com.ExecuteScalar();

    SqlCommand com2 = new SqlCommand("SELECT COUNT(*) FROM LoanStatus WHERE StatusCode < 410", cnn);
    var count2 = (int)com2.ExecuteScalar();

    SqlCommand com3 = new SqlCommand("SELECT COUNT(*) FROM LoanStatus", cnn);
    var count3 = (int)com3.ExecuteScalar();

    cnn.Close();

    
    Output o = new Output();
    o.PostClosingLoansInLine = count;
    o.ComplianceLoansInLine = count2;
    o.PostClosingLoansInLine = count3;
    o.PostClosingSuspenseLoansInLine = 0;


    /******
    Need to figure out how to get date only fron 'date' datatype, as it gives date and time 
    --using a string is a possible option
    ******/

    string ret = JsonSerializer.Serialize(o);

    return ret;
    /* v CTRL CLICK v */
    //https://localhost:5001/api/Calhfa/get

    /* 
      Our current connection string 
      "Data Source=.;Initial Catalog=biglarrydb;Integrated Security=True"
    */
  }

 }

}