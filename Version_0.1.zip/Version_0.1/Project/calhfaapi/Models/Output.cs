using System;

namespace calhfaapi.Models {
    public class Output{

        public int ComplianceLoansInLine { get; set; }
        public int SuspenseLoansInLine { get; set; }
        public int PostClosingLoansInLine { get; set; }
        public int PostClosingSuspenseLoansInLine { get; set; }

        //Dates
        public DateTime ComplianceDate { get; set; }
        public DateTime SuspenseDate { get; set; } 
        public DateTime PostClosingDate { get; set; }
        public DateTime PostClosingSuspenseDate { get; set; } 
  }
}